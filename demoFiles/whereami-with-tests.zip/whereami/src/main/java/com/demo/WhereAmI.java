package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WhereAmI
 */
@WebServlet("/")
public class WhereAmI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WhereAmI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
   
      String zone = "blue";

      int localPort = req.getLocalPort();
      String contextPath = req.getContextPath(); 
      String httpScheme = req.getScheme();
  
      System.out.println("scheme: " + httpScheme);
      System.out.println("port: " + localPort);
      System.out.println("contextPath: " + contextPath);

// Add zones based on http schema used
  
/**
      if (httpScheme == "http")
       zone = "red";
      
       if (httpScheme == "https")
       zone = "green";
**/ 

        String whereami = "Where Am I Running?"; 
      

// set title to UPPER CASE

//    whereami = whereami.toUpperCase();
    
       PrintWriter out = res.getWriter ();
    	res.setContentType("text/html");
    	out.println("<HTML><HEAD><TITLE>Where am I running?</TITLE></HEAD><BODY BGCOLOR=\"#FFFFEE\">");
    	out.println("<h1>" + whereami +  "</h1>");

    	String name = null;
    	MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
       
        try {   
       
        	ObjectName serverMBean;
    
    		serverMBean = new ObjectName(
    				"WebSphere:feature=kernel,name=ServerInfo");
    		if (mbs.isRegistered(serverMBean)) {
    			name = (String) mbs.getAttribute(serverMBean, "Name");

    			if (zone == "red")
                	out.println("<h2><font color = \"red\">The red zone!  Using an unsecure port</h2>");
    			else if (zone == "green")
                   out.println("<h2><font color = \"green\">The green zone! Using a Secure Port!</h2>");
    		
                out.println("<h3><font color = \"" + zone + "\">Server name: "+name+"</h3>");

    			String libertyVersion = (String) mbs.getAttribute(serverMBean, "LibertyVersion");	
    			out.println("Liberty Version is: "+ libertyVersion);
    		}else{
    			System.out.println("server mbean doesn't seem to exist");
    		}			
           
            out.println("<br>Host: " + InetAddress.getLocalHost().getHostName());
            out.println("<br>Scheme: " + httpScheme);
            out.println("<br>Context Path: " + contextPath);
            out.println("<br>Port: " + localPort);
            

    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}